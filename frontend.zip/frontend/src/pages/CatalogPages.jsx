import { useCallback, useEffect, useMemo, useState } from 'react';
import { Pencil, PlusCircle, X } from 'lucide-react';
import { createAssignment, createCourse, createDepartment, createSemester, createUser, getAssignments, getCourses, getDepartments, getExamCommittees, getSemesters, getUsers, saveExamCommittee, updateAssignment, updateCourse, updateDepartment, updateSemester, updateUser } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import { academicStreams, groupStudents, streamLabel, studentGroupLabel } from '../utils/academicStreams.js';

const allRoles = ['SUPER_ADMIN', 'HOD', 'EXAM_COMMITTEE', 'INSTRUCTOR', 'STUDENT'];
const semesterStatuses = ['DRAFT', 'SCHEDULED', 'OPEN', 'CLOSED', 'ARCHIVED'];
const assignmentStatuses = ['DRAFT', 'VERIFIED', 'PUBLISHED'];

function optionName(user) {
  return user ? `${user.firstName} ${user.lastName}` : '';
}

function isoDate(value) {
  return value ? new Date(value).toISOString().slice(0, 10) : '';
}

function isCommitteeUser(user) {
  return user.role === 'EXAM_COMMITTEE' || Boolean(user.committeeRoles?.length);
}

function canManage(page, user) {
  if (page === 'departments') return user.role === 'SUPER_ADMIN';
  if (page === 'semesters') return ['SUPER_ADMIN', 'HOD'].includes(user.role);
  if (page === 'courses' || page === 'assignments') return ['SUPER_ADMIN', 'HOD'].includes(user.role) || isCommitteeUser(user);
  if (page === 'users') return ['SUPER_ADMIN', 'HOD'].includes(user.role) || isCommitteeUser(user);
  return false;
}

function idOf(value) {
  return value?._id || value || '';
}

function sameId(first, second) {
  return String(idOf(first)) === String(idOf(second));
}

function roleScopedDepartments(departments, user) {
  if (user.role === 'SUPER_ADMIN') return departments;
  return departments.filter((department) => sameId(department._id, user.department));
}

function DataPage({ title, subtitle, load, columns, form, canEdit, onEdit, groupBy }) {
  const [rows, setRows] = useState(null);
  const [error, setError] = useState('');
  const refresh = useCallback(async () => {
    setError('');
    try { setRows(await load()); }
    catch (requestError) { setError(requestError.response?.data?.message || 'Data could not be loaded.'); }
  }, [load]);
  useEffect(() => { refresh(); }, [refresh]);
  const groupedRows = useMemo(() => {
    if (!rows || !groupBy) return [];
    const groups = new Map();
    rows.forEach((row) => {
      const label = groupBy(row);
      if (!groups.has(label)) groups.set(label, []);
      groups.get(label).push(row);
    });
    return [...groups];
  }, [groupBy, rows]);
  const renderRow = (row) => <div className='data-row editable-row' key={row._id}>{columns.map((column) => <div key={column.label}><small>{column.label}</small><span>{column.value(row)}</span></div>)}{canEdit && <button className='icon-action' type='button' onClick={() => onEdit(row)} title={`Edit ${title}`}><Pencil size={16} /></button>}</div>;
  if (error && !rows) return <div className='error-message'>{error}</div>;
  return <>
    {form?.({ refresh })}
    <section className='panel data-page'>
      <div className='panel-title'><div><h2>{title}</h2><p>{subtitle}</p></div><span>{rows ? rows.length : 0} records</span></div>
      {error && <div className='error-message'>{error}</div>}
      {!rows ? <div className='loading-state'>Loading from MongoDB...</div> : !rows.length ? <div className='empty-state'>No records found.</div> :
        <div className='data-table'>{groupBy ? groupedRows.map(([label, group]) => <section className='data-group' key={label}><h3>{label}</h3>{group.map(renderRow)}</section>) : rows.map(renderRow)}</div>
      }
    </section>
  </>;
}

function AdminForm({ title, children, onSubmit, message, editing, onCancel }) {
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (event) => {
    event.preventDefault(); setError(''); setBusy(true);
    try { await onSubmit(); }
    catch (requestError) { setError(requestError.response?.data?.message || 'Record could not be saved.'); }
    finally { setBusy(false); }
  };
  return <section className='panel admin-entry-panel'>
    <div className='panel-title'><div><h2>{editing ? `Edit ${title}` : `Add ${title}`}</h2><p>{message}</p></div>{editing ? <button className='icon-action' type='button' onClick={onCancel} title='Cancel edit'><X size={18} /></button> : <PlusCircle size={22} />}</div>
    <form className='admin-form' onSubmit={submit}>{children}{error && <div className='error-message'>{error}</div>}<button className='primary-action' disabled={busy}>{busy ? 'Saving...' : editing ? 'Update MongoDB' : 'Save to MongoDB'}</button></form>
  </section>;
}

export function DepartmentsPage() {
  const { user } = useAuth();
  const editable = canManage('departments', user);
  const initial = { code: '', name: '', faculty: '', hod: '' };
  const [values, setValues] = useState(initial);
  const [editingId, setEditingId] = useState('');
  const [hods, setHods] = useState([]);
  useEffect(() => { getUsers('HOD').then(setHods).catch(() => setHods([])); }, []);
  const reset = () => { setValues(initial); setEditingId(''); };
  const save = async (refresh) => {
    const payload = { code: values.code, name: values.name, faculty: values.faculty, ...(values.hod ? { hod: values.hod } : {}) };
    if (editingId) await updateDepartment(editingId, payload); else await createDepartment(payload);
    reset(); await refresh();
  };
  const edit = (row) => { setEditingId(row._id); setValues({ code: row.code || '', name: row.name || '', faculty: row.faculty || '', hod: row.hod?._id || '' }); };
  return <DataPage title='Departments' subtitle='Academic units loaded from the backend.' load={getDepartments} canEdit={editable} onEdit={edit} form={({ refresh }) => editable && <AdminForm title='Department' message='Only Super Admin can add or modify departments.' editing={Boolean(editingId)} onCancel={reset} onSubmit={() => save(refresh)}>
    <label><span>Code</span><input value={values.code} onChange={(event) => setValues({ ...values, code: event.target.value })} required placeholder='CS' /></label>
    <label><span>Department</span><input value={values.name} onChange={(event) => setValues({ ...values, name: event.target.value })} required placeholder='Computer Science' /></label>
    <label><span>Faculty</span><input value={values.faculty} onChange={(event) => setValues({ ...values, faculty: event.target.value })} required placeholder='Engineering and Technology' /></label>
    <label><span>Head</span><select value={values.hod} onChange={(event) => setValues({ ...values, hod: event.target.value })}><option value=''>Assign later</option>{hods.map((hod) => <option value={hod._id} key={hod._id}>{optionName(hod)}</option>)}</select></label>
  </AdminForm>} columns={[
    { label: 'Code', value: (row) => row.code },
    { label: 'Department', value: (row) => row.name },
    { label: 'Faculty', value: (row) => row.faculty },
    { label: 'Head', value: (row) => row.hod ? optionName(row.hod) : 'Not assigned' }
  ]} />;
}

export function SemestersPage() {
  const { user } = useAuth();
  const editable = canManage('semesters', user);
  const initial = { name: '', academicYear: '', startsAt: '', endsAt: '', evaluationOpensAt: '', evaluationClosesAt: '', status: 'DRAFT' };
  const [values, setValues] = useState(initial);
  const [editingId, setEditingId] = useState('');
  const reset = () => { setValues(initial); setEditingId(''); };
  const save = async (refresh) => {
    const payload = { ...values, evaluationOpensAt: values.evaluationOpensAt || undefined, evaluationClosesAt: values.evaluationClosesAt || undefined };
    if (editingId) await updateSemester(editingId, payload); else await createSemester(payload);
    reset(); await refresh();
  };
  const edit = (row) => { setEditingId(row._id); setValues({ name: row.name || '', academicYear: row.academicYear || '', startsAt: isoDate(row.startsAt), endsAt: isoDate(row.endsAt), evaluationOpensAt: isoDate(row.evaluationOpensAt), evaluationClosesAt: isoDate(row.evaluationClosesAt), status: row.status || 'DRAFT' }); };
  return <DataPage title='Semesters' subtitle='Evaluation windows and academic periods.' load={getSemesters} canEdit={editable} onEdit={edit} form={({ refresh }) => editable && <AdminForm title='Semester' message='Super Admin and HOD can add or modify evaluation periods.' editing={Boolean(editingId)} onCancel={reset} onSubmit={() => save(refresh)}>
    <label><span>Name</span><input value={values.name} onChange={(event) => setValues({ ...values, name: event.target.value })} required placeholder='Fall Semester' /></label>
    <label><span>Academic year</span><input value={values.academicYear} onChange={(event) => setValues({ ...values, academicYear: event.target.value })} required placeholder='2026/2027' /></label>
    <label><span>Starts</span><input type='date' value={values.startsAt} onChange={(event) => setValues({ ...values, startsAt: event.target.value })} required /></label>
    <label><span>Ends</span><input type='date' value={values.endsAt} onChange={(event) => setValues({ ...values, endsAt: event.target.value })} required /></label>
    <label><span>Evaluation opens</span><input type='date' value={values.evaluationOpensAt} onChange={(event) => setValues({ ...values, evaluationOpensAt: event.target.value })} /></label>
    <label><span>Evaluation closes</span><input type='date' value={values.evaluationClosesAt} onChange={(event) => setValues({ ...values, evaluationClosesAt: event.target.value })} /></label>
    <label><span>Status</span><select value={values.status} onChange={(event) => setValues({ ...values, status: event.target.value })}>{semesterStatuses.map((status) => <option value={status} key={status}>{status}</option>)}</select></label>
  </AdminForm>} columns={[
    { label: 'Name', value: (row) => row.name },
    { label: 'Academic Year', value: (row) => row.academicYear },
    { label: 'Status', value: (row) => row.status },
    { label: 'Evaluation Closes', value: (row) => row.evaluationClosesAt ? new Date(row.evaluationClosesAt).toLocaleDateString() : 'Not set' }
  ]} />;
}

export function CoursesPage() {
  const { user } = useAuth();
  const editable = canManage('courses', user);
  const departmentLocked = user.role !== 'SUPER_ADMIN';
  const initial = { code: '', title: '', creditHours: 3, department: '', semester: '', level: '', yearLevel: '', academicStream: '' };
  const [values, setValues] = useState(initial);
  const [editingId, setEditingId] = useState('');
  const [departments, setDepartments] = useState([]);
  const [semesters, setSemesters] = useState([]);
  const selectedDepartment = departments.find((department) => sameId(department, values.department));
  const isEceCourse = selectedDepartment?.code === 'ECE';
  useEffect(() => { Promise.all([getDepartments(), getSemesters()]).then(([loadedDepartments, loadedSemesters]) => { const availableDepartments = roleScopedDepartments(loadedDepartments, user); setDepartments(availableDepartments); setSemesters(loadedSemesters); setValues((current) => ({ ...current, department: current.department || availableDepartments[0]?._id || '', semester: current.semester || loadedSemesters[0]?._id || '' })); }).catch(() => {}); }, [user]);
  const reset = () => { setValues({ ...initial, department: departments[0]?._id || '', semester: semesters[0]?._id || '' }); setEditingId(''); };
  const save = async (refresh) => {
    const payload = { ...values, creditHours: Number(values.creditHours), yearLevel: values.yearLevel ? Number(values.yearLevel) : '' };
    if (!payload.yearLevel) delete payload.yearLevel;
    if (!payload.academicStream) delete payload.academicStream;
    if (editingId) await updateCourse(editingId, payload); else await createCourse(payload);
    reset(); await refresh();
  };
  const edit = (row) => { setEditingId(row._id); setValues({ code: row.code || '', title: row.title || '', creditHours: row.creditHours || 3, department: row.department?._id || '', semester: row.semester?._id || '', level: row.level || '', yearLevel: row.yearLevel || '', academicStream: row.academicStream || '' }); };
  return <DataPage title='Courses' subtitle='Courses and semesters loaded from the backend.' load={getCourses} canEdit={editable} onEdit={edit} form={({ refresh }) => editable && <AdminForm title='Course' message={departmentLocked ? 'Your HOD or committee account can add courses only to its assigned department. Log in as Admin to choose any department.' : 'Administrator access: choose any department and semester for this course.'} editing={Boolean(editingId)} onCancel={reset} onSubmit={() => save(refresh)}>
    <label><span>Code</span><input value={values.code} onChange={(event) => setValues({ ...values, code: event.target.value })} required placeholder='CS401' /></label>
    <label><span>Title</span><input value={values.title} onChange={(event) => setValues({ ...values, title: event.target.value })} required placeholder='Software Engineering' /></label>
    <label><span>Credit hours</span><input type='number' min='1' max='8' value={values.creditHours} onChange={(event) => setValues({ ...values, creditHours: event.target.value })} required /></label>
    <label><span>Department</span><select value={values.department} onChange={(event) => { const department = departments.find((item) => sameId(item, event.target.value)); setValues({ ...values, department: event.target.value, academicStream: department?.code === 'ECE' ? values.academicStream : '' }); }} disabled={departmentLocked} required><option value='' disabled>Select department</option>{departments.map((department) => <option value={department._id} key={department._id}>{department.name}</option>)}</select></label>
    <label><span>Semester</span><select value={values.semester} onChange={(event) => setValues({ ...values, semester: event.target.value })} required><option value='' disabled>Select semester</option>{semesters.map((semester) => <option value={semester._id} key={semester._id}>{semester.name} {semester.academicYear}</option>)}</select></label>
    <label><span>Class / section</span><input value={values.level} onChange={(event) => setValues({ ...values, level: event.target.value })} placeholder='Year 4 / Section A' /></label>
    <label><span>Year level</span><select value={values.yearLevel} onChange={(event) => { const yearLevel = event.target.value; setValues({ ...values, yearLevel, academicStream: Number(yearLevel) >= 4 ? values.academicStream : '' }); }}><option value=''>Not specified</option>{[2, 3, 4, 5].map((year) => <option value={year} key={year}>Year {year}</option>)}</select></label>
    {isEceCourse && Number(values.yearLevel) >= 4 && <label><span>Branch / stream</span><select value={values.academicStream} onChange={(event) => setValues({ ...values, academicStream: event.target.value })} required><option value='' disabled>Select stream</option>{academicStreams.map(([value, label]) => <option value={value} key={value}>{label}</option>)}</select></label>}
  </AdminForm>} columns={[
    { label: 'Code', value: (row) => row.code },
    { label: 'Course / Stream', value: (row) => `${row.title}${row.academicStream ? ` / ${streamLabel(row.academicStream)}` : ''}` },
    { label: 'Department', value: (row) => row.department?.name || '-' },
    { label: 'Semester', value: (row) => row.semester ? row.semester.name + ' ' + row.semester.academicYear : '-' }
  ]} />;
}

export function AssignmentsPage() {
  const { user } = useAuth();
  const editable = canManage('assignments', user);
  const initial = { instructor: '', course: '', semester: '', enrolledStudents: [], peerEvaluators: [], status: 'PUBLISHED' };
  const [values, setValues] = useState(initial);
  const [editingId, setEditingId] = useState('');
  const [instructors, setInstructors] = useState([]);
  const [students, setStudents] = useState([]);
  const [courses, setCourses] = useState([]);
  const [semesters, setSemesters] = useState([]);
  useEffect(() => { Promise.all([getUsers('INSTRUCTOR'), getUsers('STUDENT'), getCourses(), getSemesters()]).then(([loadedInstructors, loadedStudents, loadedCourses, loadedSemesters]) => { setInstructors(loadedInstructors); setStudents(loadedStudents); setCourses(loadedCourses); setSemesters(loadedSemesters); setValues((current) => ({ ...current, instructor: current.instructor || loadedInstructors[0]?._id || '', course: current.course || loadedCourses[0]?._id || '', semester: current.semester || loadedSemesters[0]?._id || '' })); }).catch(() => {}); }, []);
  const selectedCourse = useMemo(() => courses.find((course) => sameId(course._id, values.course)), [courses, values.course]);
  const courseDepartment = idOf(selectedCourse?.department);
  const departmentInstructors = useMemo(() => instructors.filter((instructor) => !courseDepartment || sameId(instructor.department, courseDepartment)), [courseDepartment, instructors]);
  const availableInstructors = useMemo(() => departmentInstructors.filter((instructor) => !selectedCourse?.academicStream || instructor.academicStream === selectedCourse.academicStream), [departmentInstructors, selectedCourse]);
  const availableStudents = useMemo(() => students.filter((student) => (!courseDepartment || sameId(student.department, courseDepartment)) && (!selectedCourse?.yearLevel || student.yearLevel === selectedCourse.yearLevel) && (!selectedCourse?.academicStream || student.academicStream === selectedCourse.academicStream)), [courseDepartment, selectedCourse, students]);
  const studentGroups = useMemo(() => groupStudents(availableStudents), [availableStudents]);
  const selectedStudents = useMemo(() => new Set(values.enrolledStudents), [values.enrolledStudents]);
  const availablePeers = useMemo(() => departmentInstructors.filter((instructor) => !sameId(instructor._id, values.instructor)), [departmentInstructors, values.instructor]);
  const selectedPeers = useMemo(() => new Set(values.peerEvaluators), [values.peerEvaluators]);
  useEffect(() => {
    if (!selectedCourse) return;
    const courseSemester = idOf(selectedCourse.semester);
    setValues((current) => {
      const nextInstructor = availableInstructors.some((instructor) => sameId(instructor._id, current.instructor)) ? current.instructor : availableInstructors[0]?._id || '';
      const nextStudents = current.enrolledStudents.filter((studentId) => availableStudents.some((student) => sameId(student._id, studentId)));
      const nextPeers = current.peerEvaluators.filter((peerId) => !sameId(peerId, nextInstructor) && departmentInstructors.some((instructor) => sameId(instructor._id, peerId)));
      if (sameId(current.semester, courseSemester) && sameId(current.instructor, nextInstructor) && nextStudents.length === current.enrolledStudents.length && nextPeers.length === current.peerEvaluators.length) return current;
      return { ...current, semester: courseSemester, instructor: nextInstructor, enrolledStudents: nextStudents, peerEvaluators: nextPeers };
    });
  }, [availableInstructors, availableStudents, departmentInstructors, selectedCourse]);
  const toggleStudent = (studentId) => setValues({ ...values, enrolledStudents: selectedStudents.has(studentId) ? values.enrolledStudents.filter((id) => id !== studentId) : [...values.enrolledStudents, studentId] });
  const togglePeer = (peerId) => setValues({ ...values, peerEvaluators: selectedPeers.has(peerId) ? values.peerEvaluators.filter((id) => id !== peerId) : [...values.peerEvaluators, peerId] });
  const reset = () => { const course = courses[0]; setValues({ ...initial, instructor: instructors[0]?._id || '', course: course?._id || '', semester: idOf(course?.semester) || semesters[0]?._id || '' }); setEditingId(''); };
  const save = async (refresh) => {
    const payload = {
      ...values,
      enrolledStudents: values.enrolledStudents.filter((studentId) => availableStudents.some((student) => sameId(student._id, studentId))),
      peerEvaluators: values.peerEvaluators.filter((peerId) => availablePeers.some((peer) => sameId(peer._id, peerId)))
    };
    if (editingId) await updateAssignment(editingId, payload); else await createAssignment(payload);
    reset(); await refresh();
  };
  const edit = (row) => { setEditingId(row._id); setValues({ instructor: row.instructor?._id || '', course: row.course?._id || '', semester: row.semester?._id || '', enrolledStudents: row.enrolledStudents?.map((student) => student._id) || [], peerEvaluators: row.peerEvaluators?.map((peer) => peer._id) || [], status: row.status || 'PUBLISHED' }); };
  return <DataPage title='Assignments' subtitle='Published assignments become student, peer, and HOD evaluation targets.' load={getAssignments} canEdit={editable} onEdit={edit} form={({ refresh }) => editable && <AdminForm title='Assignment' message='Choose a department course/class, then assign its instructor and enrolled students.' editing={Boolean(editingId)} onCancel={reset} onSubmit={() => save(refresh)}>
    <label><span>Instructor</span><select value={values.instructor} onChange={(event) => setValues({ ...values, instructor: event.target.value })} required disabled={!availableInstructors.length}><option value=''>{availableInstructors.length ? 'Select instructor' : 'No eligible instructor for this department / stream'}</option>{availableInstructors.map((instructor) => <option value={instructor._id} key={instructor._id}>{optionName(instructor)}{instructor.academicStream ? ` - ${streamLabel(instructor.academicStream)}` : ''}</option>)}</select></label>
    <label><span>Course / class</span><select value={values.course} onChange={(event) => setValues({ ...values, course: event.target.value })} required>{courses.map((course) => <option value={course._id} key={course._id}>{course.code} - {course.title}{course.yearLevel ? ` (Year ${course.yearLevel})` : course.level ? ` (${course.level})` : ''}{course.academicStream ? ` / ${streamLabel(course.academicStream)}` : ''}</option>)}</select></label>
    <label><span>Semester</span><select value={values.semester} disabled required>{semesters.map((semester) => <option value={semester._id} key={semester._id}>{semester.name} {semester.academicYear}</option>)}</select></label>
    <label><span>Status</span><select value={values.status} onChange={(event) => setValues({ ...values, status: event.target.value })}>{assignmentStatuses.map((status) => <option value={status} key={status}>{status}</option>)}</select></label>
    {selectedCourse && !availableInstructors.length && <div className='error-message'>No active instructor is registered in {selectedCourse.department?.name || 'this course department'}. Edit the instructor on the Users page and select this same department.</div>}
    <div className='student-picker'><span>Eligible students grouped by year and stream</span>{studentGroups.length ? studentGroups.map(([label, group]) => <div className='student-group' key={label}><strong>{label} ({group.length})</strong>{group.map((student) => <label key={student._id}><input type='checkbox' checked={selectedStudents.has(student._id)} onChange={() => toggleStudent(student._id)} />{optionName(student)} ({student.studentNumber || student.email})</label>)}</div>) : <em>No students match this course year and stream. Add or update students from the Users page first.</em>}</div>
    <div className='student-picker'><span>Peer / colleague evaluators</span>{availablePeers.length ? availablePeers.map((peer) => <label key={peer._id}><input type='checkbox' checked={selectedPeers.has(peer._id)} onChange={() => togglePeer(peer._id)} />{optionName(peer)} ({peer.email})</label>) : <em>Add another instructor in this department to assign a peer evaluation.</em>}</div>
  </AdminForm>} columns={[
    { label: 'Instructor', value: (row) => row.instructor ? optionName(row.instructor) : '-' },
    { label: 'Course / Class', value: (row) => row.course ? `${row.course.code} - ${row.course.title}${row.course.yearLevel ? ` (Year ${row.course.yearLevel})` : row.course.level ? ` (${row.course.level})` : ''}${row.course.academicStream ? ` / ${streamLabel(row.course.academicStream)}` : ''}` : '-' },
    { label: 'Students', value: (row) => row.enrolledStudents?.length || 0 },
    { label: 'Status', value: (row) => row.status || '-' }
  ]} />;
}

export function ExamCommitteesPage() {
  const [semesters, setSemesters] = useState([]);
  const [instructors, setInstructors] = useState([]);
  const [committees, setCommittees] = useState([]);
  const [semester, setSemester] = useState('');
  const [members, setMembers] = useState([]);
  const [chair, setChair] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    const [loadedSemesters, loadedInstructors, loadedCommittees] = await Promise.all([getSemesters(), getUsers('INSTRUCTOR'), getExamCommittees()]);
    setSemesters(loadedSemesters);
    setInstructors(loadedInstructors.filter((instructor) => instructor.isActive !== false));
    setCommittees(loadedCommittees);
    setSemester((current) => current || loadedSemesters[0]?._id || '');
  }, []);

  useEffect(() => { refresh().catch((requestError) => setError(requestError.response?.data?.message || 'Exam Committee data could not be loaded.')); }, [refresh]);
  useEffect(() => {
    const existing = committees.find((committee) => sameId(committee.semester, semester));
    const existingMembers = existing?.members?.map((member) => member._id) || [];
    setMembers(existingMembers);
    setChair(existing?.chair?._id || existingMembers[0] || '');
  }, [committees, semester]);

  const toggleMember = (instructorId) => {
    const next = members.includes(instructorId)
      ? members.filter((memberId) => memberId !== instructorId)
      : members.length < 3 ? [...members, instructorId] : members;
    setMembers(next);
    if (!next.includes(chair)) setChair(next[0] || '');
    setError('');
    setSuccess('');
  };

  const save = async (event) => {
    event.preventDefault();
    if (members.length !== 3) { setError('Select exactly three instructors.'); return; }
    setBusy(true); setError(''); setSuccess('');
    try {
      await saveExamCommittee({ semester, members, chair });
      await refresh();
      setSuccess('The three-instructor Exam Committee was assigned for this semester.');
    } catch (requestError) {
      setError(requestError.response?.data?.message || 'Exam Committee could not be saved.');
    } finally { setBusy(false); }
  };

  return <div className='instructor-section'>
    <section className='panel admin-entry-panel'>
      <div className='panel-title'><div><h2>Assign Exam Committee</h2><p>Select exactly three active instructors from your department for one semester.</p></div><span>{members.length} / 3 selected</span></div>
      <form className='admin-form' onSubmit={save}>
        <label><span>Semester</span><select value={semester} onChange={(event) => { setSemester(event.target.value); setSuccess(''); setError(''); }} required><option value='' disabled>Select semester</option>{semesters.map((item) => <option value={item._id} key={item._id}>{item.name} {item.academicYear}</option>)}</select></label>
        <label><span>Committee chair</span><select value={chair} onChange={(event) => setChair(event.target.value)} disabled={!members.length} required><option value='' disabled>Select chair</option>{instructors.filter((instructor) => members.includes(instructor._id)).map((instructor) => <option value={instructor._id} key={instructor._id}>{optionName(instructor)}</option>)}</select></label>
        <div className='student-picker'><span>Department instructors - select exactly three</span>{instructors.length ? instructors.map((instructor) => { const selected = members.includes(instructor._id); return <label key={instructor._id}><input type='checkbox' checked={selected} disabled={!selected && members.length >= 3} onChange={() => toggleMember(instructor._id)} />{optionName(instructor)}{instructor.academicStream ? ` / ${streamLabel(instructor.academicStream)}` : ''} ({instructor.email})</label>; }) : <em>No active instructors are registered in your department.</em>}</div>
        {instructors.length < 3 && <div className='error-message'>At least three active instructors must be registered in your department before a committee can be assigned.</div>}
        {error && <div className='error-message'>{error}</div>}
        {success && <div className='success-message'>{success}</div>}
        <button className='primary-action' disabled={busy || members.length !== 3 || !chair || !semester}>{busy ? 'Saving...' : 'Assign Exam Committee'}</button>
      </form>
    </section>
    <section className='panel data-page'>
      <div className='panel-title'><div><h2>Semester Committees</h2><p>Your department's saved Exam Committees.</p></div><span>{committees.length} records</span></div>
      {!committees.length ? <div className='empty-state'>No Exam Committee has been assigned yet.</div> : <div className='committee-grid'>{committees.map((committee) => <article className='course-roster-card' key={committee._id}><div className='course-roster-heading'><div><strong>{committee.semester?.name} {committee.semester?.academicYear}</strong><span>{committee.department?.name}</span></div><em>{committee.status}</em></div><div className='roster-title'>Three appointed instructors</div><div className='student-roster'>{committee.members.map((member) => <div key={member._id}><strong>{optionName(member)}{sameId(member, committee.chair) ? ' - Chair' : ''}</strong><small>{member.academicStream ? `${streamLabel(member.academicStream)} / ` : ''}{member.email}</small></div>)}</div></article>)}</div>}
    </section>
  </div>;
}

export function UsersPage() {
  const { user } = useAuth();
  const editable = canManage('users', user);
  const roles = user.role === 'SUPER_ADMIN' ? allRoles : isCommitteeUser(user) && user.role !== 'HOD' ? ['INSTRUCTOR', 'STUDENT'] : allRoles.filter((role) => role !== 'SUPER_ADMIN');
  const canAssignCommittees = ['SUPER_ADMIN', 'HOD'].includes(user.role);
  const initial = { firstName: '', lastName: '', email: '', password: 'Password123!', role: 'STUDENT', committeeRoles: [], department: '', studentNumber: '', yearLevel: '', gpa: '', academicStream: '', employeeNumber: '', isActive: true };
  const [values, setValues] = useState(initial);
  const [editingId, setEditingId] = useState('');
  const [departments, setDepartments] = useState([]);
  const selectedUserDepartment = departments.find((department) => sameId(department, values.department));
  const isEceUser = selectedUserDepartment?.code === 'ECE';
  const streamRequired = isEceUser && (values.role === 'INSTRUCTOR' || (values.role === 'STUDENT' && Number(values.yearLevel) >= 4));
  useEffect(() => { getDepartments().then((loadedDepartments) => { const availableDepartments = roleScopedDepartments(loadedDepartments, user); setDepartments(availableDepartments); setValues((current) => ({ ...current, department: current.department || availableDepartments[0]?._id || '' })); }).catch(() => setDepartments([])); }, [user]);
  const reset = () => { setValues({ ...initial, department: departments[0]?._id || '' }); setEditingId(''); };
  const save = async (refresh) => {
    const payload = { ...values };
    if (!payload.department) delete payload.department;
    if (!payload.studentNumber) delete payload.studentNumber;
    if (!payload.yearLevel) delete payload.yearLevel;
    if (payload.gpa === '') delete payload.gpa; else payload.gpa = Number(payload.gpa);
    if (!payload.academicStream) delete payload.academicStream;
    if (!payload.employeeNumber) delete payload.employeeNumber;
    if (editingId && !payload.password) delete payload.password;
    if (editingId) await updateUser(editingId, payload); else await createUser(payload);
    reset(); await refresh();
  };
  const toggleCommittee = (committeeRole) => setValues({ ...values, committeeRoles: values.committeeRoles.includes(committeeRole) ? values.committeeRoles.filter((role) => role !== committeeRole) : [...values.committeeRoles, committeeRole] });
  const edit = (row) => { setEditingId(row._id); setValues({ firstName: row.firstName || '', lastName: row.lastName || '', email: row.email || '', password: '', role: row.role || 'STUDENT', committeeRoles: row.committeeRoles || [], department: row.department?._id || '', studentNumber: row.studentNumber || '', yearLevel: row.yearLevel || '', gpa: row.gpa ?? '', academicStream: row.academicStream || '', employeeNumber: row.employeeNumber || '', isActive: row.isActive !== false }); };
  return <DataPage title='Users' subtitle='Active evaluation system accounts grouped by academic cohort.' load={getUsers} canEdit={editable} onEdit={edit} groupBy={(row) => row.role === 'STUDENT' ? `${row.department?.name || 'No department'} / ${studentGroupLabel(row)}` : 'Staff accounts'} form={({ refresh }) => editable && <AdminForm title='User' message='ECE instructors and Year 4-5 students must belong to one of the four academic streams.' editing={Boolean(editingId)} onCancel={reset} onSubmit={() => save(refresh)}>
    <label><span>First name</span><input value={values.firstName} onChange={(event) => setValues({ ...values, firstName: event.target.value })} required /></label>
    <label><span>Last name</span><input value={values.lastName} onChange={(event) => setValues({ ...values, lastName: event.target.value })} required /></label>
    <label><span>Email</span><input type='email' value={values.email} onChange={(event) => setValues({ ...values, email: event.target.value })} required /></label>
    <label><span>Password</span><input type='password' value={values.password} onChange={(event) => setValues({ ...values, password: event.target.value })} minLength={editingId ? undefined : 8} required={!editingId} placeholder={editingId ? 'Leave blank to keep current password' : ''} /></label>
    <label><span>Role</span><select value={values.role} onChange={(event) => { const role = event.target.value; setValues({ ...values, role, studentNumber: role === 'STUDENT' ? values.studentNumber : '', yearLevel: role === 'STUDENT' ? values.yearLevel : '', gpa: role === 'STUDENT' ? values.gpa : '', employeeNumber: role === 'STUDENT' ? '' : values.employeeNumber, academicStream: isEceUser && role === 'INSTRUCTOR' ? values.academicStream : '' }); }}>{roles.map((role) => <option value={role} key={role}>{role.replaceAll('_', ' ')}</option>)}</select></label>
    <label><span>Department</span><select value={values.department} onChange={(event) => { const department = departments.find((item) => sameId(item, event.target.value)); setValues({ ...values, department: event.target.value, academicStream: department?.code === 'ECE' ? values.academicStream : '' }); }} required={values.role !== 'SUPER_ADMIN'}>{values.role === 'SUPER_ADMIN' && <option value=''>University-wide</option>}{departments.map((department) => <option value={department._id} key={department._id}>{department.name}</option>)}</select></label>
    <label><span>Student number</span><input value={values.studentNumber} onChange={(event) => setValues({ ...values, studentNumber: event.target.value })} required={values.role === 'STUDENT'} placeholder='Students only' /></label>
    {values.role === 'STUDENT' && <label><span>Year level</span><select value={values.yearLevel} required={isEceUser} onChange={(event) => { const yearLevel = event.target.value; setValues({ ...values, yearLevel, academicStream: Number(yearLevel) >= 4 ? values.academicStream : '' }); }}><option value=''>Not specified</option>{[2, 3, 4, 5].map((year) => <option value={year} key={year}>Year {year}</option>)}</select></label>}
    {values.role === 'STUDENT' && <label><span>GPA</span><input type='number' min='0' max='4' step='0.01' value={values.gpa} onChange={(event) => setValues({ ...values, gpa: event.target.value })} placeholder='Required for stream allocation' /></label>}
    {streamRequired && <label><span>Branch / stream</span><select value={values.academicStream} onChange={(event) => setValues({ ...values, academicStream: event.target.value })} required><option value='' disabled>Select one stream</option>{academicStreams.map(([value, label]) => <option value={value} key={value}>{label}</option>)}</select></label>}
    <label><span>Employee number</span><input value={values.employeeNumber} onChange={(event) => setValues({ ...values, employeeNumber: event.target.value })} placeholder='Staff only' /></label>
    {canAssignCommittees && values.role === 'INSTRUCTOR' && <div className='student-picker'><span>HOD-appointed committee duties</span><label><input type='checkbox' checked={values.committeeRoles.includes('COURSE_COMMITTEE')} onChange={() => toggleCommittee('COURSE_COMMITTEE')} />Course Committee - manage courses, classes, rosters and peer assignments</label><em>Assign Exam Committee membership in the semester Exam Committee page, where exactly three instructors are required.</em></div>}
    <label className='checkbox-field'><input type='checkbox' checked={values.isActive} onChange={(event) => setValues({ ...values, isActive: event.target.checked })} />Active account</label>
  </AdminForm>} columns={[
    { label: 'Name', value: (row) => row.firstName + ' ' + row.lastName },
    { label: 'Email', value: (row) => row.email },
    { label: 'Role / Duties', value: (row) => [row.role.replaceAll('_', ' '), ...(row.committeeRoles || []).map((role) => role.replaceAll('_', ' '))].join(' / ') },
    { label: 'Department / Cohort', value: (row) => `${row.department?.name || 'University-wide'}${row.role === 'STUDENT' ? ` / ${studentGroupLabel(row)}${typeof row.gpa === 'number' ? ` / GPA ${row.gpa.toFixed(2)}` : ''}` : row.academicStream ? ` / ${streamLabel(row.academicStream)}` : ''}` }
  ]} />;
}

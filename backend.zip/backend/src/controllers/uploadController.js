import { parse } from 'csv-parse/sync';
import { User } from '../models/User.js';
import { validateUserAcademicProfile } from '../utils/academicProfile.js';
import { asyncHandler } from '../utils/asyncHandler.js';

function importError(message, statusCode = 400) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

function requiredText(value, field, rowNumber) {
  const text = String(value || '').trim();
  if (!text) throw importError(`Row ${rowNumber}: ${field} is required`);
  return text;
}

function optionalNumber(value, field, rowNumber) {
  if (value === undefined || value === null || String(value).trim() === '') return undefined;
  const number = Number(value);
  if (!Number.isFinite(number)) throw importError(`Row ${rowNumber}: ${field} must be a number`);
  return number;
}

export const uploadStudents = asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'CSV file is required' });
  if (!req.file.originalname.toLowerCase().endsWith('.csv')) {
    return res.status(400).json({ message: 'Only CSV files are accepted' });
  }
  let records;
  try {
    records = parse(req.file.buffer, { columns: true, skip_empty_lines: true, trim: true });
  } catch {
    throw importError('The CSV file could not be parsed. Check its header and row formatting.');
  }
  if (!records.length) throw importError('The CSV file contains no student records');
  if (records.length > 1000) throw importError('A single CSV import is limited to 1000 students');

  const seenEmails = new Set();
  const prepared = [];
  for (const [index, record] of records.entries()) {
    const rowNumber = index + 2;
    const email = requiredText(record.email, 'email', rowNumber).toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) throw importError(`Row ${rowNumber}: email is invalid`);
    if (seenEmails.has(email)) throw importError(`Row ${rowNumber}: duplicate email ${email}`);
    seenEmails.add(email);

    const requestedDepartment = String(record.department || req.user.department || '').trim();
    if (!requestedDepartment) throw importError(`Row ${rowNumber}: department is required`);
    if (req.user.role !== 'SUPER_ADMIN' && String(req.user.department || '') !== requestedDepartment) {
      throw importError(`Row ${rowNumber}: you can only import students into your department`, 403);
    }

    const yearLevel = optionalNumber(record.yearLevel, 'yearLevel', rowNumber);
    const gpa = optionalNumber(record.gpa, 'gpa', rowNumber);
    const profile = {
      role: 'STUDENT',
      department: requestedDepartment,
      yearLevel,
      gpa,
      academicStream: String(record.academicStream || '').trim() || undefined
    };
    await validateUserAcademicProfile(profile);
    if (yearLevel !== undefined && (!Number.isInteger(yearLevel) || yearLevel < 2 || yearLevel > 5)) {
      throw importError(`Row ${rowNumber}: yearLevel must be an integer from 2 to 5`);
    }
    if (gpa !== undefined && (gpa < 0 || gpa > 4)) throw importError(`Row ${rowNumber}: GPA must be between 0 and 4`);

    const existing = await User.findOne({ email });
    if (existing && existing.role !== 'STUDENT') throw importError(`Row ${rowNumber}: ${email} belongs to a non-student account`, 409);
    if (existing && req.user.role !== 'SUPER_ADMIN' && String(existing.department || '') !== String(req.user.department)) {
      throw importError(`Row ${rowNumber}: you cannot modify a student in another department`, 403);
    }
    prepared.push({
      existing,
      password: String(record.password || ''),
      payload: {
        firstName: requiredText(record.firstName, 'firstName', rowNumber),
        lastName: requiredText(record.lastName, 'lastName', rowNumber),
        email,
        studentNumber: requiredText(record.studentNumber, 'studentNumber', rowNumber),
        ...profile
      }
    });
  }

  const results = [];
  for (const item of prepared) {
    let user;
    if (item.existing) {
      Object.assign(item.existing, item.payload);
      if (item.password) item.existing.passwordHash = await User.hashPassword(item.password);
      user = await item.existing.save();
    } else {
      user = await User.create({
        ...item.payload,
        passwordHash: await User.hashPassword(item.password || 'Password123!'),
        isEmailVerified: true,
        isActive: true
      });
    }
    results.push({ email: user.email, id: user.id });
  }
  res.status(201).json({ imported: results.length, students: results });
});

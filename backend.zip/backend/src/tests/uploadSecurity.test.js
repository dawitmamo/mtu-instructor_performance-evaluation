import request from 'supertest';
import { MongoMemoryServer } from 'mongodb-memory-server';
import { createApp } from '../app.js';
import { connectDb, disconnectDb } from '../config/db.js';
import { Department } from '../models/Department.js';
import { User } from '../models/User.js';
import { signAccessToken } from '../utils/tokens.js';

let mongo;
let app;
let department;
let foreignDepartment;
let hod;
let instructor;
let student;

function auth(user) {
  return { Authorization: `Bearer ${signAccessToken(user)}` };
}

function csvRow({ email, departmentId, firstName = 'Imported', lastName = 'Student', studentNumber = 'EE-CSV-1' }) {
  return [
    'firstName,lastName,email,studentNumber,department',
    `${firstName},${lastName},${email},${studentNumber},${departmentId}`
  ].join('\n');
}

beforeAll(async () => {
  mongo = await MongoMemoryServer.create();
  await connectDb(mongo.getUri());
  app = createApp();
});

afterAll(async () => {
  await disconnectDb();
  await mongo.stop();
});

beforeEach(async () => {
  await Promise.all([User.deleteMany({}), Department.deleteMany({})]);
  [department, foreignDepartment] = await Department.create([
    { name: 'Electrical Engineering', code: 'EE', faculty: 'Engineering' },
    { name: 'Civil Engineering', code: 'CE', faculty: 'Engineering' }
  ]);
  const passwordHash = await User.hashPassword('OriginalPassword123!');
  [hod, instructor, student] = await User.create([
    { firstName: 'Department', lastName: 'Head', email: 'upload.hod@example.edu', passwordHash, role: 'HOD', department: department._id },
    { firstName: 'Existing', lastName: 'Instructor', email: 'existing.instructor@example.edu', passwordHash, role: 'INSTRUCTOR', department: department._id },
    { firstName: 'Existing', lastName: 'Student', email: 'existing.student@example.edu', passwordHash, role: 'STUDENT', department: department._id, studentNumber: 'EE-OLD' }
  ]);
});

test('department CSV imports cannot cross departments or overwrite staff accounts', async () => {
  await request(app)
    .post('/api/uploads/students')
    .set(auth(hod))
    .attach('file', Buffer.from(csvRow({ email: 'foreign.student@example.edu', departmentId: foreignDepartment.id })), 'students.csv')
    .expect(403);

  await request(app)
    .post('/api/uploads/students')
    .set(auth(hod))
    .attach('file', Buffer.from(csvRow({ email: instructor.email, departmentId: department.id })), 'students.csv')
    .expect(409);

  expect((await User.findById(instructor.id)).role).toBe('INSTRUCTOR');
});

test('updating a student by CSV preserves the current password unless a new password is provided', async () => {
  await request(app)
    .post('/api/uploads/students')
    .set(auth(hod))
    .attach('file', Buffer.from(csvRow({ email: student.email, departmentId: department.id, firstName: 'Updated', studentNumber: 'EE-NEW' })), 'students.csv')
    .expect(201);

  const updated = await User.findById(student.id);
  expect(updated.firstName).toBe('Updated');
  expect(updated.studentNumber).toBe('EE-NEW');
  const login = await request(app).post('/api/auth/login').send({ email: student.email, password: 'OriginalPassword123!' }).expect(200);
  expect(login.body.user.role).toBe('STUDENT');
});
